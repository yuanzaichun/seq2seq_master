# mini seq2seq
Minimal Seq2Seq model with attention for neural machine translation in PyTorch.

This implementation focuses on the following features:

- Modular structure to be used in other projects
- Minimal code for readability
- Full utilization of batches and GPU.

This implementation relies on [torchtext](https://github.com/pytorch/text) to minimize dataset management and preprocessing parts.

## Model description

* Encoder: Bidirectional GRU
* Decoder: GRU with Attention Mechanism
* Attention: [Neural Machine Translation by Jointly Learning to Align and Translate](https://arxiv.org/abs/1409.0473)

![](http://www.wildml.com/wp-content/uploads/2015/12/Screen-Shot-2015-12-30-at-1.16.08-PM.png)

## Requirements

* GPU & CUDA
* Python3
* PyTorch
* torchtext
* Spacy
* numpy
* Visdom (optional)

download tokenizers by doing so:
```
python -m spacy download de
python -m spacy download en
```


## References

Based on the following implementations

* [PyTorch Tutorial](http://pytorch.org/tutorials/intermediate/seq2seq_translation_tutorial.html)
* [@spro/practical-pytorch](https://github.com/spro/practical-pytorch)
* [@AuCson/PyTorch-Batch-Attention-Seq2seq](https://github.com/AuCson/PyTorch-Batch-Attention-Seq2seq)


这个GitHub存储库包含了一些用于序列到序列学习的代码实现，其中包括了以下文件：

1、data.py: 用于读取和处理数据集的代码，生成模型训练所需的数据格式。

2、layers.py: 包含了用于定义Seq2Seq网络各层的类。

3、model.py: 包含了定义 Seq2Seq 模型结构的核心代码。其中包括编码器和解码器的定义、注意力机制等。

4、train.py: 主要用于模型训练的代码。该脚本会读取数据并将其输入到模型中进行训练。它也会设置模型参数、损失函数、优化器等内容。

5、translate.py: 用于使用已经预训练好的 Seq2Seq 模型进行翻译任务。

6、utils.py: 包含一些通用的实用程序函数，例如保存和加载模型权重、计算评估指标等。

此外，存储库还包含一个data目录，其中包含多个翻译任务的数据集，以及一些预训练权重文件。

总的来说，这个存储库提供了一个完整的 Seq2Seq 学习框架，涵盖了数据预处理、模型定义、训练和测试等方面的内容，可用于自然语言处理相关的任务，如翻译、对话等。