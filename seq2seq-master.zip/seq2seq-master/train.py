import os
import math
import argparse
import torch
from torch import optim
from torch.autograd import Variable
from torch.nn.utils import clip_grad_norm_
from torch.nn import functional as F
from model import Encoder, Decoder, Seq2Seq
from utils import load_dataset

#模型训练的代码
args = {"batch_size": 32}  # 示例args对象，具体内容可能有所不同

train_iter, val_iter, test_iter, DE, EN = load_dataset(args["batch_size"])

def parse_arguments():
    p = argparse.ArgumentParser(description='Hyperparams')
    p.add_argument('-epochs', type=int, default=10,
                   help='number of epochs for train')   #训练次数
    p.add_argument('-batch_size', type=int, default=32,
                   help='number of epochs for train')       #训练大小
    p.add_argument('-lr', type=float, default=0.0001,
                   help='initial learning rate')        #初始学习率
    p.add_argument('-grad_clip', type=float, default=10.0,
                   help='in case of gradient explosion')        #梯度暴增时裁剪最大值
    return p.parse_args()


def evaluate(model, val_iter, vocab_size, DE, EN):      #DE，EN 源语言和目标语言的field对象
    with torch.no_grad():
        model.eval()        #要评估的模型
        pad = EN.vocab.stoi['<pad>']
        total_loss = 0
        for b, batch in enumerate(val_iter):    #包含验证集的迭代器
            src, len_src = batch.src
            trg, len_trg = batch.trg
            src = src.data.cuda()
            trg = trg.data.cuda()
            output = model(src, trg, teacher_forcing_ratio=0.0)
            loss = F.nll_loss(output[1:].view(-1, vocab_size),      #目标语言词汇表的大小
                                   trg[1:].contiguous().view(-1),
                                   ignore_index=pad)
            total_loss += loss.data.item()
        return total_loss / len(val_iter)


def train(e, model, optimizer, train_iter, vocab_size, grad_clip, DE, EN):  #训练模型的函数、e：当前epoch迭代次数的索引。
    #model：要训练的模型。
    #optimizer：优化器对象，例如Adam或SGD。
    #train_iter：包含训练集的迭代器。
    #vocab_size：目标语言词汇表的大小。
    #grad_clip：在梯度爆炸时限制梯度的最大值。
    model.train()       #将模型设置为训练模式
    total_loss = 0
    pad = EN.vocab.stoi['<pad>']
    for b, batch in enumerate(train_iter):
        src, len_src = batch.src
        trg, len_trg = batch.trg
        src, trg = src.cuda(), trg.cuda()
        optimizer.zero_grad()
        output = model(src, trg)
        loss = F.nll_loss(output[1:].view(-1, vocab_size),
                               trg[1:].contiguous().view(-1),
                               ignore_index=pad)
        loss.backward()
        clip_grad_norm_(model.parameters(), grad_clip)  #将梯度裁剪至指定范围内
        optimizer.step()
        total_loss += loss.data.item()

        if b % 100 == 0 and b != 0:
            total_loss = total_loss / 100
            print("[%d][loss:%5.2f][pp:%5.2f]" %
                  (b, total_loss, math.exp(total_loss)))
            total_loss = 0


def main():
    args = parse_arguments()
    hidden_size = 512           #超参数
    embed_size = 256
    assert torch.cuda.is_available()

    print("[!] preparing dataset...")
    train_iter, val_iter, test_iter, DE, EN = load_dataset(args.batch_size) #加载训练、验证和测试数据
    # batch_size作为参数传递给load_dataset()函数，以指定每个批次包含多少个样本。
    de_size, en_size = len(DE.vocab), len(EN.vocab)
    print("[TRAIN]:%d (dataset:%d)\t[TEST]:%d (dataset:%d)"
          % (len(train_iter), len(train_iter.dataset),
             len(test_iter), len(test_iter.dataset)))
    print("[DE_vocab]:%d [en_vocab]:%d" % (de_size, en_size))

    print("[!] Instantiating models...")
    encoder = Encoder(de_size, embed_size, hidden_size,
                      n_layers=2, dropout=0.5)      #将源语言序列编码为向量表示的模块
    decoder = Decoder(embed_size, hidden_size, en_size,
                      n_layers=1, dropout=0.5)      #将编码后的源语言向量解码为目标语言序列的模块
    seq2seq = Seq2Seq(encoder, decoder).cuda()      #将encoder和decoder组合起来以形成完整的Seq2Seq模型
    optimizer = optim.Adam(seq2seq.parameters(), lr=args.lr)    #优化模型的权重，并将学习率设置为args.lr
    print(seq2seq)

    #训练和验证之后对模型进行测试
    best_val_loss = None
    for e in range(1, args.epochs+1):
        train(e, seq2seq, optimizer, train_iter,
              en_size, args.grad_clip, DE, EN)
        val_loss = evaluate(seq2seq, val_iter, en_size, DE, EN)     #打印出测试集损失值
        print("[Epoch:%d] val_loss:%5.3f | val_pp:%5.2fS"
              % (e, val_loss, math.exp(val_loss)))

        # Save the model if the validation loss is the best we've seen so far.
        if not best_val_loss or val_loss < best_val_loss:
            print("[!] saving model...")
            if not os.path.isdir(".save"):
                os.makedirs(".save")
            torch.save(seq2seq.state_dict(), './.save/seq2seq_%d.pt' % (e))
            best_val_loss = val_loss
    test_loss = evaluate(seq2seq, test_iter, en_size, DE, EN)
    print("[TEST] loss:%5.2f" % test_loss)
    #测试之前，该代码还检查是否有一个名为.save的文件夹存在。如果不存在，则会创建该文件夹，并将最佳的模型权重保存到该文件夹中


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt as e:
        print("[STOP]", e)
