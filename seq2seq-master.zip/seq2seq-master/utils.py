import re
from torchtext.data import Field, BucketIterator
from torchtext.datasets import Multi30k
import spacy

#包含一些通用的实用程序函数，如保存和加载模型权重、计算评估指标
def load_dataset(batch_size):       #加载源语言和目标语言的数据集，并创建用于训练、验证和测试的迭代器对象
    spacy_de = spacy.load('de')
    spacy_en = spacy.load('en')
    url = re.compile('(<url>.*</url>)')


    #分别对德文和英文进行分词处理
    def tokenize_de(text):
        return [tok.text for tok in spacy_de.tokenizer(url.sub('@URL@', text))]

    def tokenize_en(text):
        return [tok.text for tok in spacy_en.tokenizer(url.sub('@URL@', text))]

    DE = Field(tokenize=tokenize_de, include_lengths=True,
               init_token='<sos>', eos_token='<eos>')
    EN = Field(tokenize=tokenize_en, include_lengths=True,
               init_token='<sos>', eos_token='<eos>')
    train, val, test = Multi30k.splits(exts=('.de', '.en'), fields=(DE, EN))    #加载数据集
    DE.build_vocab(train.src, min_freq=2)       #分别为源语言和目标语言创建词汇表
    EN.build_vocab(train.trg, max_size=10000)
    train_iter, val_iter, test_iter = BucketIterator.splits(
            (train, val, test), batch_size=batch_size, repeat=False)    #将训练、验证和测试数据集转换为迭代器
    return train_iter, val_iter, test_iter, DE, EN
